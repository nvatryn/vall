# Autoscrip
link instal

apt install -y && apt update -y && apt upgrade -y && wget -q https://raw.githubusercontent.com/ovva123/Autoscript/GM/ubu20-deb10-stable.sh && chmod +x ubu20-deb10-stable.sh && ./ubu20-deb10-stable.sh
